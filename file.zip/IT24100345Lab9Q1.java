import java.util.Scanner;

public class IT24100345Lab9Q1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter value a : ");
        float val_a = sc.nextFloat();

        System.out.print("Enter value b : ");
        float val_b = sc.nextFloat();

        System.out.print("Enter value c : ");
        float val_c = sc.nextFloat();

        double cal = Math.sqrt(val_b * val_b - 4 * val_a * val_c); // b² - 4ac

        //check discriminant
        if(Double.isNaN(cal)) {
            System.out.println("Roots are not real");
            return;
        }

        System.out.printf(cal > 0 ? "\nRoots are real and different :\nRoot 1 : %.2f\nRoot 2 : %.2f\n"
                                  : "\nRoots are real but same : \nRoot 1 : %.2f \nRoot 2 : %.2f\n",
                         (-val_b / 2 * val_a ) + cal, (-val_b / 2 * val_a ) - cal);

    }

}
