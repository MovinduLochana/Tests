import java.util.Arrays;

public class IT24100345Lab9Q3 {

    public static void main(String[] args) {

        System.out.println("Result of (3 ∗ 4 + 5 ∗ 7)² \t\t: " + square(add(prod(3, 4), prod(5, 7))));

        System.out.println("Result of (4 + 7)² + (8 + 3)² \t: " + add(square(add(4, 7)), square(add(8, 3))));
    }

    private static int add(int a, int b) {
        return a + b;
    }

    private static int prod(int a, int b) {
        return a * b;
    }

    private static int square(int val) {
        return val * val;
    }

}
