import java.util.LinkedHashMap;
import java.util.Scanner;

public class IT24100345Lab9Q4 {

    public static void main(String[] args) {

        var sc = new Scanner(System.in);
        var data = new LinkedHashMap<String, Integer>();

        for (int i = 0; i < 5; i++) {
            System.out.print("\nEnter Name : ");
            String name = sc.next();

            System.out.print("Enter Assignment Marks : ");
            int assignmentMarks = sc.nextInt();

            System.out.print("Enter Exam Marks : ");
            int examMarks = sc.nextInt();

            data.put(name, calcFinalMarks(assignmentMarks, examMarks));
        }

        sc.close();
        printDetails(data);
    }

    private static int calcFinalMarks(int assignmentMarks, int examMarks) {
        return (int) (assignmentMarks * 0.3 + examMarks * 0.7);
    }

    private static char findGrades(int marks) {
        return marks >= 75 ? 'A' : marks >= 60 ? 'B' : marks >= 50 ? 'c' : marks > 0 ? 'F' : 'X';
    }

    private static void printDetails(LinkedHashMap<String, Integer> map) {
        System.out.println("\nName \t Marks \t Grade ");
        map.forEach((k, v) -> System.out.printf("%s \t %d \t %c \n", k, v, findGrades(v)));
    }
}
