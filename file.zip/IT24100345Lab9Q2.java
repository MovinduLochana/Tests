import java.util.Scanner;

public class IT24100345Lab9Q2 {

    public static void main(String[] args) {

        System.out.print("Enter Radius : ");
        System.out.printf("\nArea is : %.4f", area(new Scanner(System.in).nextFloat()));

    }

    private static float area(float radius) {
        return (float) Math.PI * radius * radius;
    }

}
